package app;

import java.util.Scanner;

public class Email {
//	Step 1 :- 
	
	private String firstName ;
	private String lastName ;
	private String password ;
	private String department ;
	private String email;
	private String companySuffix = "aeycompany.com";
	private int mailboxCapacity = 100;
	private String alternateEmail ;
	private int defaultPasswordLength = 8;
	
//	Construcotor to recieve the firstname and lastname
	public Email( String firstName, String lastName) {
		
		this.firstName = firstName;
		this.lastName = lastName;
//		System.out.println("EMAIL CREATED : "+ this.firstName + " "+ this.lastName);
		
		// call a method asking for department:
		this.department = setDepartment();
//		System.out.println("Department: "+ this.department);
		
		// call a method that returns a random password:
		this.password = randomPassword(defaultPasswordLength);
//		System.out.println("Your Password is: "+ this.password);
		
		// Combine elements to generate email:
		this.email = firstName.toLowerCase()+"."+ lastName.toLowerCase()+"@"+department+"."+companySuffix;
//		System.err.println("Your Email is : "+ email);
		
		

		
	}
	
	
	
//	ask for the department
	private String setDepartment() {
		System.out.println("New Worker: "+firstName+ "\nDepartment Codes:\n1 for Sales\n2 for Development\n3 for Accounting\n0 for none\nEnter Department Code");
		Scanner in = new Scanner(System.in);
		int depChoice = in.nextInt();
		if (depChoice == 1 ) { return "sales";}
		else if (depChoice == 2 ) { return "dev";}
		else if (depChoice == 3 ) { return "acct";}
		else { return "";}
	}
	
	
//	Generate a random password
	private String randomPassword(int length) {
		
		String passwordSet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ!@#$%&";
		char[] password = new char[length];
		for(int i= 0; i<length; i++) {
			int rand = (int) (Math.random()* passwordSet.length());
			password[i] = passwordSet.charAt(rand);
		}
		return new String(password);
	}
	
	
//	set the mailbox capacity
	public void setMailboxCapacity(int capacity) {
		
		this.mailboxCapacity = capacity;
//		System.out.println("This is your new Mail capacity: "+ this.mailboxCapacity);
	}
	
	
	
	
//	set the alternaet email
	public void setAlternateEmail(String altEmail) {
			
			this.alternateEmail = altEmail;
//			System.out.println("This is your new Email: "+ this.alternateEmail);
			
		}

	
	
//	Change the password
	public void changePassword(String password) {
		
		this.password = password;
//		System.out.println("This is your new Password: "+ this.password);
	}
	
	
//	GET METHODS:-
	
	public int getMailBoxCapacity() {
		return mailboxCapacity;
	}
	
	public String getAlternateEmail() {
		System.out.println(alternateEmail);
		return alternateEmail;
	}
	
	public String getPassword() {
		System.out.println(password);
		return password;
	}
	
//	Method for show information:
	
	public String showInfo() {
		return "\nDISPLAY NAME: "+ firstName+" "+ lastName+ "\nCOMPANY EMAIL: "+email+ "\nMAILBOX CAPACITY: "+ mailboxCapacity+ "mb";
	}
	
	

}
