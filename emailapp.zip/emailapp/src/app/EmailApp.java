package app;

public class EmailApp {

	public static void main(String[] args) {
		
		Email em1 = new Email("Mohit","Jangid");
		
//		em1.changePassword("ajksfh");
//		em1.setAlternateEmail("mjangid@cisco.com");
//		em1.setMailboxCapacity(10);
//		
//		
//		em1.getAlternateEmail();
//		em1.getPassword();
		System.out.println(em1.showInfo());

	}

}
